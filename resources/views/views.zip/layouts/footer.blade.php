<!-- footer starts -->
<footer class="border-top text-center" id="footer">
    <div class="container">
        <p class="py-3">
            Copyright © <script>
                document.write(/\d{4}/.exec(Date())[0])
            </script> Vincent Luhur
        </p>
    </div>
</footer>
<!-- footer ends -->
