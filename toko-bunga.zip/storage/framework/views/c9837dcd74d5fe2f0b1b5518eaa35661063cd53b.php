<div class="row border-bottom">
    <nav class="navbar navbar-static-top bg-white" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn" href="#"><i
                    class="fa fa-bars"></i> </a>
            <form role="search" class="navbar-form-custom" action="search_results.html">
                <div class="form-group">
                    
                </div>
            </form>
        </div>

        <ul class="nav navbar-top-links navbar-right">
            <li>
                <img alt="image" class="rounded-circle" src="<?php echo e(asset('assets/img/user.png')); ?>"  width="30px"/>
            </li>
            
           
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle align-self-center" href="#">
                    <span class="text-muted text-xl block"><?php echo e(auth()->guard('staff')->user()->name); ?><b class="caret"></b></span>
                </a>
                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    
                    <li><a class="dropdown-item" href="/logout">Logout</a></li>
                </ul>
            </li>
        </ul>

    </nav>
</div>
<?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/backend/layouts/topbar.blade.php ENDPATH**/ ?>