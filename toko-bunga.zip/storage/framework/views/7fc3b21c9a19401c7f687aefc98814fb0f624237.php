

<?php $__env->startSection('title', 'Decoration'); ?>

<?php $__env->startSection('content'); ?>

<style>

    .carousel{
        margin-top: -50px;
    }
    @media  only screen and (min-width: 768px) and (max-width: 991px) {
        .w-100{
            height: auto;
        }
        footer{
            margin-top:-240px;
        }
        .carousel{
            margin-top: 0px;
        }
        body{
            overflow-y: hidden;
        }
    }
    @media  only screen and (max-width: 767px) {
        .w-100{
            height: auto;
        }
        footer{
            margin-top:-330px;
        }
        .carousel{
            margin-top: 0px;
        }
        html, body{
            overflow: hidden !important;
        }

    }
</style>
    <div class="container">
        <div class="carousel slide pb-5" data-bs-ride="carousel" id="carouselExampleIndicators">
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-1.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-2.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-3.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-4.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-5.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-6.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-7.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-8.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-9.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-10.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-11.jpg')); ?>">
                </div>
                <div class="carousel-item">
                    <img alt="..." class="d-block w-100" src="<?php echo e(asset('assets/img/decoration/DECORATION-12.jpg')); ?>">
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/frontend/decoration/index.blade.php ENDPATH**/ ?>