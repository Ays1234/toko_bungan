<div class="footer">
    <div class="float-right">
        Support by <strong class="text-danger">Rapier Technology International</strong>
    </div>
    <div>
        <strong>Copyright</strong> Vincent Luhur &copy; <script>
            document.write(/\d{4}/.exec(Date())[0])
        </script>
    </div>
</div>



<?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>