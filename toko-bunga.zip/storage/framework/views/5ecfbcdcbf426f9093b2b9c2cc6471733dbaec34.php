

<?php $__env->startSection('title', 'Press'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .title{
        font-size: 48px;
        padding: 50px 0;
    }
    .paragraf p{
        font-size: 17px;
        padding: 10px 0;
        line-height: 2;
    }
    .py-35,{
        padding: 35px 0;
    }
    .paragraf img{
        padding: 20px 0 35px 0;
    }
    .description h2{
        font-size: 24px;
    }
    .description li{
        font-size: 13px;
    }
    .b-font::first-letter{
        padding-right: 15px;
        margin: -60px 0;
        font-size: 110px;
        float: left;
    }
    @media  only screen and (max-width: 767px) {
        .paragraf h2{
            font-size: 26px;
        }
    }
</style>

<?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="section-padding">
    <img src="<?php echo e(asset('storage/'.$baca->photo_banner_article)); ?>" alt="" class="img-fluid" width="100%">
    <div class="container px-5 mb-5">
        <div class="paragraf">
            <h2 class="text-center fw-bold title"><?php echo e($baca->judul); ?></h2>
            <p class="b-font">
                <div class="prose lg:prose-xl"><?php echo $baca->deskripsi; ?></div>
                
            </p>
            
        </div>
    </div>
</section>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/frontend/press/baca.blade.php ENDPATH**/ ?>