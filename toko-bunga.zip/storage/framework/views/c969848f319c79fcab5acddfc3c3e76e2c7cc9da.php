

<?php $__env->startSection('title', 'Press'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .press a{
        text-decoration: none;
        color: black;
    }
    #press{
        color: #898989;
    }
    #press:hover{
        color: #c49a6c;
    }
    #title:hover{
        color: #5b5b5b;
    }
    .press p{
        font-size: 14px;
    }
    .line-height{
        line-height: 2;
    }
    .article{
        margin-bottom: 85px;
    }
    #title h4{
        line-height: 1.5;
    }

    
</style>


<section class="section-padding">
    <div class="container">
        <div class="row">
            
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 article">
                <img src="<?php echo e(asset('storage/'.$item->thumbnail)); ?>" alt="profile-2" class="img-fluid" width="100%">
                <div class="press">
                    <a href="press/baca/<?php echo e($item->id); ?>" id="press">
                        <p class=" my-4">Press</p>
                    </a>
                    <a href="press/baca/<?php echo e($item->id); ?>" id="title">
                        <h4 class=" fw-bold my-4"><?php echo e($item->judul); ?></h4>
                    </a>
                    <p class="line-height">Vincent Luhur Flowers &amp; Design merancang dekorasi pernikahan dengan menggunakan hanya 1 jenis bunga Import dari Vietnam, yaitu Eustoma russellianum…</p>
                </div>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/frontend/press/index.blade.php ENDPATH**/ ?>