<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand-l home-logo-mobile" href="<?php echo e(route('home')); ?>">
            <img alt="..." class="logo" src="<?php echo e(asset('assets/img/logo/logo-black-mobile.png')); ?>">
        </a>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">About</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile.index')); ?>">Profile</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('press.index')); ?>">Press</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('services.index')); ?>">Services</a>
                </li>
                <li class="home-logo2">
                    <a class="navbar-brand-l" href="<?php echo e(route('home')); ?>">
                        <img alt="..." class="logo" src="<?php echo e(asset('assets/img/logo/logo-black.png')); ?>">
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">Projects</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('decoration.index')); ?>">Decoration</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('floral.index')); ?>">Floral Styling</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contact.index')); ?>">Contact</a>
                </li>
                </li>
                
            </ul>
        </div>
        <div class="nav-mobile">
            <a class="btn mr-4" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample" style="color:#c49a6c;">
                <i class="fa fa-bars fa-2x"></i>
            </a>
            <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
                <div class="offcanvas-header">
                    <img alt="..." class="" src="<?php echo e(asset('assets/img/logo/LOGO_VL_D_COLOR+BLACK.png')); ?>" width="15%">
                    <button type="button" class="btn btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <div class="dropdown mt-3">
                        <ul class="navbar-nav mx-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">About</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(route('profile.index')); ?>">Profile</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('press.index')); ?>">Press</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('services.index')); ?>">Services</a>
                            </li>
                            <li class="home-logo2">
                                <a class="navbar-brand-l" href="<?php echo e(route('home')); ?>">
                                    <img alt="..." class="logo" src="<?php echo e(asset('assets/img/logo/logo-white.png')); ?>">
                                </a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" aria-expanded="false">Projects</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php echo e(route('decoration.index')); ?>">Decoration</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('floral.index')); ?>">Floral Styling</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('contact.index')); ?>">Contact</a>
                            </li>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
</nav>
<?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>