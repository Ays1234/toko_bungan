<nav class="navbar-default navbar-static-side" role="navigation" style="background: #ffff;">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <img alt="..." class="logo" src="<?php echo e(asset('assets/img/logo/logo-black-mobile.png')); ?>" width="100%">
                    
                </div>
                <div class="logo-element">
                    CMS
                </div>
            </li>
            <li class="<?php echo e(request()->routeIs('dashboard.index') ? 'active' : ''); ?>">
                <a href=""><i class="fa fa-th-large"></i> <span class="nav-label">Beranda</span></a>
            </li>
            <li >
                <a href="<?php echo e(Route::currentRouteName() === 'staff.index'|| Route::currentRouteName() === 'category.index'  ? 'active' : ''); ?>"><i class="fa fa-th-large"></i> <span class="nav-label">Master</span>
                    <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li ><a href="<?php echo e(route('staff.index')); ?>">Staff</a></li>
                    <li ><a href="<?php echo e(route('category.index')); ?>">Category Press</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Content</span>
                    <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="<?php echo e(route('carrousel.index')); ?>">Carrousel Benner</a></li>
                    <li><a href="<?php echo e(route('article.index')); ?>">Press/Article</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Projects</span>
                    <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="<?php echo e(route('decoration_cms.index')); ?>">Decoration</a></li>
                    <li><a href="<?php echo e(route('floral_cms.index')); ?>">Floral Styling</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Keamanan</span>
                    <span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="#">Management Access</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Log Activitas</span></a>
            </li>
        </ul>

    </div>
</nav>
<?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/backend/layouts/navigation.blade.php ENDPATH**/ ?>