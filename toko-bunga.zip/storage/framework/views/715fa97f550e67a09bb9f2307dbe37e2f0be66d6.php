
<?php $__env->startSection('title', 'Decoration'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom page-heading">
    <div class="col-lg-10">
        <h2><?php echo $__env->yieldContent('title'); ?></h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard.index')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="#">Project</a>
            </li>
            <li class="breadcrumb-item active">
                <strong><?php echo $__env->yieldContent('title'); ?></strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-title">
                    <h4 class="font-weight-bold">Data <?php echo $__env->yieldContent('title'); ?></h4>
                    <div class="ibox-tools">
                        <div class="p-0 text-right">
                            <a href="<?php echo e(route('decoration_cms.form')); ?>" class="btn btn-primary b-r-xl"><i
                                    class="fa fa-plus-circle"></i>&nbsp;
                                Tambah</a>
                        </div>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive m-3">
                        <table id="table1" class="table p-3">
                            <thead>
                                <tr>
                                    <th width="5%" class="align-middle">#</th>
                                    <th class="align-middle">Photo</th>
                                    <th class="align-middle">Nama</th>
                                    <th class="align-middle">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $decoration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <img alt="..." class="d-block rounded" src="<?php echo e(asset('storage/'.$item->image_decoration)); ?>" width="300px">
                                    </td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <div class='btn-group'>
                                            <a href="/decoration_cms/edit/<?php echo e($item->id); ?>"><button
                                                    class="btn btn-secondary btn-sm" type="button">
                                                    <i class="fa fa-pencil"></i>
                                                </button></a>
                                        </div>
                                        <div class='btn-group'>
                                            <form action="/destroy_decoration/<?php echo e($item->id); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-dark btn-sm" type="button">
                                                    <i class="fa fa-trash"></i>
                                                </button></form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        table = $('#table1').DataTable({
            pageLength: 10,
            responsive: true,
            "searching": false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy' },
                // { extend: 'csv' },
                // { extend: 'excel', title: 'ExampleFile' },
                // { extend: 'pdf', title: 'ExampleFile' },

                // {
                //     extend: 'print',
                //     customize: function (win) {
                //         $(win.document.body).addClass('white-bg');
                //         $(win.document.body).css('font-size', '10px');
                //         $(win.document.thead).css('background:#1ab394', '10px');

                //         $(win.document.body).find('table')
                //             .addClass('compact')
                //             .css('font-size', 'inherit');
                //     }
                // }
            ]
        });
        table = $('#table_detail').DataTable({
            paging:false,
            responsive: true,
            "searching": false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                // { extend: 'copy' },
                // { extend: 'csv' },
                // { extend: 'excel', title: 'ExampleFile' },
                // { extend: 'pdf', title: 'ExampleFile' },

                // {
                //     extend: 'print',
                //     customize: function (win) {
                //         $(win.document.body).addClass('white-bg');
                //         $(win.document.body).css('font-size', '10px');
                //         $(win.document.thead).css('background:#1ab394', '10px');

                //         $(win.document.body).find('table')
                //             .addClass('compact')
                //             .css('font-size', 'inherit');
                //     }
                // }
            ]
        });
    });

     //message with toastr
     <?php if(session()->has('success')): ?>

toastr.success('<?php echo e(session('success')); ?>', 'BERHASIL!');
<?php elseif(session()->has('error')): ?>

toastr.error('<?php echo e(session('error')); ?>', 'GAGAL!');
<?php endif; ?>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/backend/project/decoration/index.blade.php ENDPATH**/ ?>