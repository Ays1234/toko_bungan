<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<title>Vincent Luhur - Flowers & Design | <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" type="image/x-icon" href="assets/img/fav.ico">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

	<link href="<?php echo e(asset('assets/style_layout.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/inspinia/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('stylesheets'); ?>
</head>
<body >

    <!-- Navigation -->
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main view  -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- All Js -->
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('.carousel').carousel({
                interval: 1000 * 2
            });
        })
    </script>
</body>
</html>
<?php /**PATH C:\Users\RAPIER\Documents\project\toko-bunga\resources\views/layouts/layout.blade.php ENDPATH**/ ?>